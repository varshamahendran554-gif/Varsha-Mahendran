"""Concept explanation using the local LaMini-Flan-T5-783M model.

The model is loaded lazily on first use (about 3 GB download the first time).
If transformers/torch are unavailable, we fall back to Gemini so the app still works.
"""
from gemini_client import generate

MODEL_NAME = "MBZUAI/LaMini-Flan-T5-783M"
_pipe = None
_local_ok = True


def _load():
    global _pipe, _local_ok
    if _pipe is None and _local_ok:
        try:
            from transformers import pipeline
            _pipe = pipeline("text2text-generation", model=MODEL_NAME)
        except Exception:
            _local_ok = False
    return _pipe


def explain_concept(topic: str) -> str:
    prompt = f"Explain the following concept in simple words for a beginner: {topic}"
    pipe = _load()
    try:
        if pipe is not None:
            out = pipe(prompt, max_length=300, do_sample=True, temperature=0.4)
            return out[0]["generated_text"].strip()
        return generate(prompt)  # fallback
    except Exception as e:
        return f"Error: {e}"

"""Quiz generation: 3 MCQs, 4 options each, returned as a Python list."""
import json
import re
from gemini_client import generate


def clean_json_block(text: str) -> str:
    """Strip Markdown code fences (```json ... ```) around a JSON reply."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(text: str):
    prompt = (
        "Create exactly 3 multiple-choice questions from the topic or passage "
        "below. Each question needs exactly 4 plausible options. Respond ONLY "
        "with a valid JSON array in this format, with no extra text:\n"
        '[{"question": "...", "options": ["A", "B", "C", "D"], '
        '"answer": "<must be identical to one of the options>"}]\n\n'
        f"Topic or passage:\n{text}"
    )
    try:
        raw = generate(prompt, json_output=True)
        quiz = json.loads(clean_json_block(raw))
        if not isinstance(quiz, list) or not quiz:
            raise ValueError("Model did not return a list of questions.")
        for q in quiz:
            if len(q.get("options", [])) != 4 or q.get("answer") not in q["options"]:
                raise ValueError("A question is missing 4 options or a valid answer.")
        return quiz[:3]
    except json.JSONDecodeError as e:
        return {"error": f"Could not parse quiz JSON: {e}"}
    except Exception as e:
        return {"error": str(e)}

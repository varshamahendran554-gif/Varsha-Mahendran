"""Personalized learning paths with Gemini."""
from gemini_client import generate


def get_learning_recommendations(topic: str) -> str:
    prompt = (
        f"Create a structured learning path for the topic: {topic}.\n"
        "Organize it from Beginner to Intermediate to Advanced. For each level give:\n"
        "- The key concepts to learn, in order\n"
        "- A realistic timeline (e.g. 'Weeks 1-2')\n"
        "- Useful resources (videos, articles, or books)\n"
        "- One small practice task\n"
        "Finish with 2-3 tips for staying on track. Use clear headings."
    )
    try:
        return generate(prompt)
    except Exception as e:
        return f"Error: {e}"

# EduGenie: Google Gemini Powered Learning Assistant

Ask questions, get simple explanations, generate quizzes, summarize passages and
get personalized learning paths. FastAPI backend + HTML/CSS frontend.

## Setup
1. Python 3.10+ (`python --version`)
2. `python -m venv venv && source venv/bin/activate` (Windows: `venv\Scripts\activate`)
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and put in your Gemini API key
   (https://aistudio.google.com/apikey).
5. Run: `uvicorn main:app --reload`
6. Open http://127.0.0.1:8000

## Endpoints (POST, JSON body `{"text": "..."}`)
| Path | Module | Model |
|---|---|---|
| `/qa` | qna.py | Gemini |
| `/explain` | explanation_module.py | LaMini-Flan-T5-783M (local; falls back to Gemini) |
| `/quiz` | quiz_module.py | Gemini (3 MCQs, 4 options, JSON) |
| `/summarize` | summary_module.py | Gemini |
| `/learn/recommendations` | learning_path.py | Gemini |

## Notes
- The project document names Gemini 1.5 Pro, which Google has retired. The model is set by
  `GEMINI_MODEL` in `.env` (default `gemini-2.5-flash`).
- The first `/explain` call downloads LaMini-Flan-T5-783M (~3 GB). To skip that,
  remove `transformers`, `torch` and `sentencepiece` from requirements; `/explain` then uses Gemini.
- Never commit your `.env` file.

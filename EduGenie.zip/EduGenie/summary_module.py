"""Summarization with Gemini."""
from gemini_client import generate


def summarize_text(text: str) -> str:
    prompt = (
        "Summarize the following educational passage into a concise, "
        "easy-to-understand version suitable for quick revision. Keep the key "
        "facts, remove redundancy, and use short bullet points if helpful.\n\n"
        f"Passage:\n{text}"
    )
    try:
        return generate(prompt)
    except Exception as e:
        return f"Error: {e}"

"""Shared Gemini helper used by qna, quiz, summary and learning-path modules."""
import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
_client = None


def _get_client():
    global _client
    if _client is None:
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            raise RuntimeError("GEMINI_API_KEY is not set. Add it to your .env file.")
        _client = genai.Client(api_key=key)
    return _client


def generate(prompt: str, json_output: bool = False) -> str:
    """Send a prompt to Gemini and return the text of the reply."""
    config = types.GenerateContentConfig(
        response_mime_type="application/json" if json_output else "text/plain"
    )
    response = _get_client().models.generate_content(
        model=MODEL, contents=prompt, config=config
    )
    text = getattr(response, "text", None)
    if not text:
        raise ValueError("Gemini returned an empty or blocked response.")
    return text.strip()
